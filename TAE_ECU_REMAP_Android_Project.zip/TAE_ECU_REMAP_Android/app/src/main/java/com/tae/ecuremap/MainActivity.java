package com.tae.ecuremap;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.*;
import android.hardware.usb.*;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.tae.ecuremap.USB_PERMISSION";
    private UsbManager usbManager;
    private TextView status, deviceInfo;
    private LinearLayout deviceList;
    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (ACTION_USB_PERMISSION.equals(intent.getAction())) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                    if (device != null && granted) {
                        status.setText("ได้รับอนุญาตให้เข้าถึง USB แล้ว");
                        showDevice(device);
                    } else {
                        status.setText("ยังไม่ได้รับอนุญาตให้เข้าถึง USB");
                    }
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) {
                refreshDevices();
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(intent.getAction())) {
                status.setText("ถอดอุปกรณ์ USB แล้ว");
                deviceInfo.setText("ยังไม่มีอุปกรณ์เชื่อมต่อ");
                refreshDevices();
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usbManager = (UsbManager) getSystemService(USB_SERVICE);
        buildUi();
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED);
        refreshDevices();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 38, 28, 28);
        page.setBackgroundColor(0xFF101114);
        scroll.addView(page);

        TextView title = text("TAE ECU REMAP", 27, 0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        page.addView(title);
        TextView sub = text("HONDA MOTORCYCLE ECU TOOL • ANDROID", 11, 0xFFFF4B4B);
        sub.setGravity(Gravity.CENTER);
        page.addView(sub);

        status = text("สถานะ: ยังไม่เชื่อมต่อ", 17, 0xFFFFFFFF);
        status.setPadding(0, 32, 0, 12);
        page.addView(status);

        Button scan = button("ตรวจหาอุปกรณ์ USB");
        scan.setOnClickListener(v -> refreshDevices());
        page.addView(scan);

        deviceInfo = text("ยังไม่มีอุปกรณ์เชื่อมต่อ", 14, 0xFFCCCCCC);
        deviceInfo.setPadding(0, 18, 0, 18);
        page.addView(deviceInfo);

        TextView heading = text("เมนูระบบ", 20, 0xFFFFFFFF);
        heading.setPadding(0, 16, 0, 12);
        page.addView(heading);

        String[] menu = {"ข้อมูล ECU", "Live Data", "อ่านรหัสขัดข้อง DTC",
                "จัดการไฟล์สำรอง", "Fuel / Ignition Map Editor", "Read / Write ECU"};
        for (String item : menu) {
            Button b = button(item);
            b.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle(item)
                    .setMessage("โมดูลนี้ยังรอการยืนยันรุ่น ECU และโปรโตคอลที่รองรับ\nขณะนี้ยังไม่ส่งคำสั่งไปยังกล่อง ECU")
                    .setPositiveButton("ตกลง", null).show());
            page.addView(b);
        }

        TextView warning = text(
                "ความปลอดภัย: รุ่นทดลองนี้ตรวจพบอุปกรณ์ USB และขอสิทธิ์ Android เท่านั้น " +
                "ยังไม่อ่าน/เขียน ECU และไม่ส่งคำสั่งจูน จนกว่าจะยืนยันชิป USB, วงจร K-Line, pinout และโปรโตคอล ECU",
                12, 0xFFFFB3B3);
        warning.setPadding(0, 26, 0, 20);
        page.addView(warning);
        setContentView(scroll);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB71C1C));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 6, 0, 6);
        b.setLayoutParams(p);
        return b;
    }

    private void refreshDevices() {
        deviceList = new LinearLayout(this);
        java.util.HashMap<String, UsbDevice> devices = usbManager.getDeviceList();
        if (devices.isEmpty()) {
            status.setText("สถานะ: ไม่พบอุปกรณ์ USB");
            deviceInfo.setText("เสียบสาย USB ECU ผ่าน OTG แล้วกดตรวจหาอุปกรณ์");
            return;
        }
        status.setText("พบอุปกรณ์ USB " + devices.size() + " รายการ");
        StringBuilder info = new StringBuilder();
        for (UsbDevice d : devices.values()) {
            info.append("ชื่อ: ").append(d.getDeviceName())
                .append("\nVID: 0x").append(String.format(Locale.US, "%04X", d.getVendorId()))
                .append("  PID: 0x").append(String.format(Locale.US, "%04X", d.getProductId()))
                .append("\nInterfaces: ").append(d.getInterfaceCount()).append("\n\n");
            Button connect = button("ขออนุญาตเชื่อมต่อ USB");
            connect.setOnClickListener(v -> requestUsbPermission(d));
            ((LinearLayout)((ScrollView)findViewById(android.R.id.content).getChildAt(0))
                    .getChildAt(0)).addView(connect);
        }
        deviceInfo.setText(info.toString());
    }

    private void requestUsbPermission(UsbDevice device) {
        PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),
                PendingIntent.FLAG_MUTABLE);
        usbManager.requestPermission(device, pi);
    }

    private void showDevice(UsbDevice d) {
        deviceInfo.setText("อุปกรณ์ที่อนุญาตแล้ว\n" + d.getDeviceName()
                + "\nVID: " + d.getVendorId() + " / PID: " + d.getProductId()
                + "\nจำนวน Interface: " + d.getInterfaceCount()
                + "\n\nขั้นต่อไป: ตรวจสอบชิป USB-to-serial และโปรโตคอล ECU");
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
