# TAE ECU REMAP — Android starter project

รุ่นนี้เป็นโครงสร้างเริ่มต้นของแอป Android สำหรับตรวจพบ USB OTG และขอสิทธิ์เข้าถึงอุปกรณ์
ยังไม่ใช่เครื่องมือรีแมพที่พร้อมอ่าน/เขียน ECU

## เปิดโปรเจกต์
1. ติดตั้ง Android Studio บนคอมพิวเตอร์
2. แตกไฟล์ ZIP
3. เปิดโฟลเดอร์ `TAE_ECU_REMAP_Android` ด้วย Android Studio
4. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หากระบบร้องขอ
5. ต่อโทรศัพท์ Android ที่รองรับ USB Host/OTG แล้วกด Run

## ข้อจำกัดในรุ่น 0.1.0
- ตรวจพบ USB device และแสดง VID/PID/interface
- ขอสิทธิ์ USB จาก Android
- เมนู ECU, Live Data, DTC, Map Editor และ Read/Write เป็นหน้ารอพัฒนา
- ไม่มีคำสั่งสื่อสารกับ ECU, ไม่มีการอ่านแฟลช และไม่มีการเขียนแฟลช
- ยังไม่มี APK ที่คอมไพล์แล้ว เนื่องจากต้อง Build ด้วย Android SDK/Gradle ใน Android Studio

## ข้อมูลที่ต้องยืนยันก่อนพัฒนาการเชื่อมต่อจริง
1. VID/PID ของสาย USB เมื่อเสียบกับ Android (ดูจากแอป USB Device Info หรือจากหน้าตรวจพบ USB ในแอปนี้)
2. ยี่ห้อ/รุ่นชิป USB-to-serial เช่น FTDI, CH340, CP210x หรือรุ่นอื่น
3. ภาพชัด ๆ ของฉลากสายและหัวต่อทุกด้าน
4. หมายเลขอะไหล่ ECU (เช่น 38770-xxx-xxx หรือ 30400-xxx-xxx) และรุ่น/ปีรถ
5. ผังขาและแรงดันของอะแดปเตอร์ S6 K-Line

## ความปลอดภัย
ห้ามทดลองเขียน ECU ด้วยโปรโตคอลที่เดาเอง ต้องยืนยัน protocol, memory layout, checksum,
security access และขั้นตอน recovery สำหรับ ECU หมายเลขนั้นก่อนเสมอ
ควรเริ่มจากการตรวจจับอุปกรณ์และอ่านข้อมูลแบบไม่เปลี่ยนแปลงค่าเท่านั้น
